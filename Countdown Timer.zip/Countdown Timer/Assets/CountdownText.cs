﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Text))]
public class CountdownText : MonoBehaviour
{
    public delegate void CountdownFinished();
    public static event CountdownFinished OnCountdownFinished;

    public int startTime = 90;
    Text countdown;

    void OnEnable()
    {
        countdown = GetComponent<Text>();
        countdown.text = startTime.ToString();
        StartCoroutine("Countdown");
    }

    // Update is called once per frame
    IEnumerator Countdown()
    {
        for (int i = 0; i < startTime; i++)
        {
            countdown.text = (startTime - i).ToString();
            yield return new WaitForSeconds(1);
        }

        OnCountdownFinished();
    }
}
